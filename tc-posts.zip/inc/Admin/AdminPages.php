<?php 

/* Admin Pages for TC posts plugin
* @package TC_Posts 
*/

namespace Inc\Admin;


class Admin_Pages {

  function __construct() {
    // nothing here
  }
}

