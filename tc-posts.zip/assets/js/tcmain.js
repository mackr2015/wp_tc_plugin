jQuery(function($){
  //console.log('admin js from TC plugin');
  
});